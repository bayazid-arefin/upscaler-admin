const mongoose = require('mongoose');

const Userschema = mongoose.Schema(
    {
        userName : {
            type : String
        },
        deviceName : {
            type : String,
            required : true
        },
        osBuild : {
            type : String,
            required : true
        },
        privetKey : {
            type : String,
            required : true
        }
    },
    {
        timestamps : false
    }
);

const User = mongoose.model('User', Userschema);
module.exports= User;