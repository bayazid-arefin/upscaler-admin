import { useContext } from "react";
import { AuthContex } from "../../Provider/AuthProvider";
import UserLIst from "./UserList/UserLIst";
import { Link } from "react-router-dom";

const Home = () => {
    const {logOut, user} = useContext(AuthContex);
    return (
        <>
            {user.uid?
            <section>
                <header className="text-center text-white bg-dark p-5 m-0">
                    <h1>Upscelar Admin</h1>
                </header>
                <UserLIst/>
                <div className="display_justify container mb-5">
                    <Link to="add-user"><button className="btn btn-success m-0">Add User</button></Link>
                    <button className="btn btn-primary m-0"><span onClick={logOut} style={{"cursor":"pointer"}}>Log Out</span></button>
                </div> 

            </section>
            : <h3 className="mt-5 text-center text-secondary">Loading ...</h3> 
            }
        </>
        
    );
};

export default Home;