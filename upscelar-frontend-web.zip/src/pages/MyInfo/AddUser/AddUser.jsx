import axios from "axios";

const AddUser = () => {
    const handelUserCreate =(e) =>{
        e.preventDefault();
        const userName = e.target.user_name.value;
        const privetKey = e.target.privet_key.value;
        const deviceInfoInp = e.target.device_info.value;
        const deviceName = deviceInfoInp?.split("\n")[0].split("\t")[1];
        if(privetKey.length < 6){
            return alert("privet key at least 6 digit")
        }
        else if(!deviceName){
            return alert("Device not found")
        }
        
        else{
            const obj = {userName, osBuild:"Windows_NT", deviceName, privetKey};
            axios.post('https://upscelar-node.arefins-classroom.com/users/list/add', obj)
            .then(res => {
                if(res.status == 200){
                    alert("user added successfully!");
                    document.getElementById("add-user-form").reset()
                }
            })
            .catch(err => console.log(err))
        }
    }
    return (
        <div className="container create_user_box">
            <h1>Create a User</h1>
            <form onSubmit={handelUserCreate} id="add-user-form" autoComplete="off" spellCheck={false}>
                <input type="text" name="user_name" className="form-control my-2" placeholder="User Name" />
                <input type="text" name="os_name" className="form-control my-2" placeholder="Os Build" value={"Windows_NT Win-32"} disabled />
                <input type="number" name="privet_key" className="form-control my-2" placeholder="Privet Key" />
                <textarea className="form-control my-2" name="device_info" placeholder="Device Info" rows={7} />
                <div className="text-center mt-3">
                    <button className="btn btn-primary">Add Now</button>
                </div>
            </form>
        </div>
    );
};

export default AddUser;