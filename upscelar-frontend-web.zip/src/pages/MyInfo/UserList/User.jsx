import axios from "axios";

const User = ({item}) => {
    const {deviceName, osBuild, privetKey, userName, _id} = item;

    const handelDelete = () =>{
        axios.delete(`https://upscelar-node.arefins-classroom.com/user/list/delete/single/${_id}`)
        .then(res => {
            if(res.status==200){
                alert("user deleted successfully!")
                window.location.reload()
            }
        })
        .catch(err => console.log(err))
    }
    return (
        <div className="user_box my-3">
            <p>User Name: <span className="bg-dark text-white p-1 rounded">{userName}</span></p>
            <p className="mt-2">Device Name: {deviceName}</p>
            <p>Os Build: {osBuild}</p>
            <p>Privet Key: {privetKey}</p>
            <p>Product Key: {_id}</p>
            <button className="btn btn-danger mt-3" onClick={handelDelete}>Delete</button>
        </div>
    );
};

export default User;