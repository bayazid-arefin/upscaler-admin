import axios from "axios";
import { useEffect, useState } from "react";
import User from "./User";

const UserLIst = () => {
    const [users, setUsers] = useState([])
    useEffect(()=>{
        axios.get(`https://upscelar-node.arefins-classroom.com/users/list/view`)
        .then(res => setUsers(res.data))
        .catch(err => console.log(err))
    }, [])
    return (
        <div className="container text-center">
            <h1 className="my-5">User List {`(${users?.length})`}</h1>
            {
                users && users.map(item => <User key={item._id} item={item}/>)
            }
        </div>
    );
};

export default UserLIst;