// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";

// Your web app's Firebase configuration
const firebaseConfig = {
    apiKey: "AIzaSyBd1UZeF8Q3HpSR16zKkgqxgV-BdQzr6Iw",
    authDomain: "upscelar.firebaseapp.com",
    projectId: "upscelar",
    storageBucket: "upscelar.appspot.com",
    messagingSenderId: "938029820663",
    appId: "1:938029820663:web:40563cf2cfe869552801f2"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
export default auth;