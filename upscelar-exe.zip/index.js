const os = require('os');
const fs = require('fs');
const path = require('path');
const sharp = require('sharp');

require('./renderar/database')
const {app, BrowserWindow, Menu, ipcMain, shell} = require('electron');

process.env.NODE_ENV= "production";
const isMac = process.platform === "darwin";
const isDev = process.env.NODE_ENV !== "production"
const computerName = os.hostname()
let lastDest;

// model
const User = require('./models/user.model');

let mainWindow;
function createMainWindow (){
    mainWindow = new BrowserWindow({
        title:"Upscaler",
        width:1000,
        height:650,
        webPreferences:{
            contextIsolation: true,
            nodeIntegration: true,
            preload: path.join(__dirname, "preload.js")
        }
    })

    if(isDev){
        mainWindow.webContents.openDevTools()
    }

    mainWindow.loadFile(path.join(__dirname, "./renderar/index.html"))
}

// menu template
const menu = [
    {
        label:'File',
        submenu:[
            {
                label: "Open Dest",
                click: ()=>lastDest && shell.openPath(lastDest),
                accelerator:"Ctrl+O"
            },
            {
                label: "Exit",
                click: ()=>app.quit(),
                accelerator:"Ctrl+W"
            }
        ]
    }
]

app.whenReady().then(()=>{
    createMainWindow()
    const mainMenu = Menu.buildFromTemplate(menu);
    Menu.setApplicationMenu(mainMenu);

    // remove main menu from memory on close
    mainWindow.on('closed', ()=> {mainWindow == null})

    app.on('activate', ()=>{
        if(BrowserWindow.getAllWindows().length==0){
            createMainWindow()
        }
    })
})

// response ipc renderer resize
ipcMain.on('image:resize', (e, options)=>{
    options.dest = path.join(options?.folderDest, 'upscaler');
    resizeImage(options)
    lastDest= options.dest;
})

// resize the image
async function resizeImage (data){
    const {imgPath, width, height, dest} = data;
    try{
        const fileName = path.basename(imgPath);

        // create destination folder if doesnot exits
        if(!fs.existsSync(dest)){
            fs.mkdirSync(dest)
        }


        // resize image
        sharp(fs.readFileSync(imgPath))
        .jpeg({
            quality: 100,
            chromaSubsampling: '4:4:4'
        })
        .resize(+width, +height)
        .toFile(path.join(dest, fileName))

        // send success message
        mainWindow.webContents.send('image:done')
    }
    catch(err){
        console.log(err)
    }
}

// handel license
ipcMain.on('get-users', (e, keyData)=>{
    handelGetUser(keyData)
})
async function handelGetUser (key){
    try{
        const user = await User.find({privetKey: key.privetKey})
        if(user[0].deviceName == computerName){
            mainWindow.webContents.send('user:done', JSON.stringify(user[0]))
        }
    }
    catch(err){
        console.log(err)
    }
}


app.on('window-all-closed', ()=>{
    if(!isMac){
        app.quit()
    }
})

