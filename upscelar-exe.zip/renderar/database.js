const mongoose = require('mongoose');

mongoose.connect('mongodb+srv://webbayazidarefin:hlW229uI9jfcbck9@resize-image.9z417.mongodb.net/?retryWrites=true&w=majority&appName=resize-image')
.then(() => console.log('Database connect successfully'))
.catch((error)=>{console.log(error)})
