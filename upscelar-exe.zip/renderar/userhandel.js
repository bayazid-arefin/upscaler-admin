const privetKey = document.getElementById("privet_password")
const privetKeyBtn = document.getElementById("handel_privet_key_btn")
const deviceInfo = document.getElementById('device_info')
const userName = document.getElementById('user_name')
const deviceNameInp = document.getElementById('device_name')
const deviceOSInp = document.getElementById('os_build')
const logInBtn = document.getElementById('log_in_btn')
const logInContainer = document.getElementById('login_container')
const homeContainer = document.getElementById('home_container')
const productKey = document.getElementById('product_key')



let userInfo;
privetKeyBtn.addEventListener('click', ()=>{
    deviceInfo.style.display="none"
    if(!privetKey.value){
        return;
    }
    const obj ={privetKey: privetKey.value};
    ipcRenderer.send("get-users", obj);
})

ipcRenderer.on('user:done', (data)=>{
    userInfo = JSON.parse(data);
    if(userInfo.deviceName){
        privetKeyBtn.style.display ="none";
        privetKey.value = "";
        deviceInfo.style.display="block"
        userName.innerText= userInfo.userName;
        productKey.innerText= userInfo._id;
        deviceNameInp.innerText = userInfo.deviceName;
        deviceOSInp.innerText = userInfo.osBuild;
    }
})

logInBtn.addEventListener('click', ()=>{
    logInContainer.style.display="none"
    homeContainer.style.display="flex"
})