const inputFile = document.getElementById("input-file")
const totalFilesBox = document.getElementById("total_files_box")
const totalFilesLength = document.getElementById("total_files_length")
const totalTimesLength = document.getElementById("total_times_length")
const progressBar = document.getElementById("progress_bar")
const submitBtn = document.getElementById("submit_button")
const progressStatus = document.getElementById("progress_status")
const messageText = document.getElementById("message_text")
const percentShow = document.getElementById('parcent_show')


let folderInfo = [];
inputFile.addEventListener("change", ()=>{
    const uploadFiles = inputFile.files;
    folderInfo = uploadFiles;
    totalFilesBox.style.display="block";
    totalFilesLength.innerText = folderInfo?.length;
    const time = parseInt(folderInfo?.length /80);
    totalTimesLength.innerText=time||1;
    currentState=0;
    progressBar.style.display="none"
    progressStatus.style.width= "0%";
    submitBtn.style.display ="inline-block"
    messageText.style.display="none"
    percentShow.innerText=""
})

submitBtn.addEventListener("click", ()=>{
    progressBar.style.display="block"
    progressStatus.style.backgroundColor="#0b0735";
    handelSender()
})


// handel sender
let currentState = 0;
const handelSender = () =>{
    const image = new Image();
    image.src = URL.createObjectURL(folderInfo[currentState]);

    image.onload = function(){
        const imgPath = folderInfo[currentState]?.path;
        const pathArr = imgPath.split("\\");
        pathArr?.pop();
        const folderDest = pathArr.join("\\")
    
        ipcRenderer.send('image:resize', {
            imgPath,
            folderDest,
            width: this.width*4,
            height: this.height*4
        })
        currentState += 1;
        const parcent = parseInt(((currentState)/folderInfo.length)*100)+"%";
        percentShow.innerText = parcent;
        progressStatus.style.width= parcent;
        if(parcent == "100%"){
            progressStatus.style.backgroundColor="green";
            submitBtn.style.display ="none"
            messageText.innerText="You can also select a new folder for take action."
            messageText.style.display="block"
            folderInfo=[];
        }
    }        
}

// get success message
ipcRenderer.on('image:done', ()=>{
    if(currentState < folderInfo.length){
        handelSender()
    }
})
